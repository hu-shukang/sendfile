export class Coordinate {
  private ctx: CanvasRenderingContext2D;
  private width: number;
  private height: number;
  private tickStep = 10;
  private readonly padding = 20;
  private readonly arrowSize = 8;

  constructor(props: {
    ctx: CanvasRenderingContext2D;
    width: number;
    height: number;
  }) {
    this.height = props.height;
    this.width = props.width;
    this.ctx = props.ctx;
  }

  public draw() {
    this.ctx.fillStyle = '#666666';
    this.ctx.strokeStyle = '#666666';
    this.drawAxis();
    this.drawTicks();
  }

  private drawAxis() {
    // draw X axis
    this.ctx.beginPath();
    this.ctx.moveTo(this.padding, this.height / 2);
    this.ctx.lineTo(this.width - this.padding, this.height / 2);
    this.ctx.stroke();

    // draw X arrow
    this.ctx.beginPath();
    this.ctx.moveTo(this.width - this.padding, this.height / 2);
    this.ctx.lineTo(
      this.width - this.padding - this.arrowSize,
      this.height / 2 - this.arrowSize,
    );
    this.ctx.lineTo(
      this.width - this.padding - this.arrowSize,
      this.height / 2 + this.arrowSize,
    );
    this.ctx.closePath();
    this.ctx.fill();

    // draw Y axis
    this.ctx.beginPath();
    this.ctx.moveTo(this.width / 2, this.padding);
    this.ctx.lineTo(this.width / 2, this.height - this.padding);
    this.ctx.stroke();

    // draw Y arrow
    this.ctx.beginPath();
    this.ctx.moveTo(this.width / 2, this.padding);
    this.ctx.lineTo(
      this.width / 2 - this.arrowSize,
      this.padding + this.arrowSize,
    );
    this.ctx.lineTo(
      this.width / 2 + this.arrowSize,
      this.padding + this.arrowSize,
    );
    this.ctx.closePath();
    this.ctx.fill();
  }

  private drawTicks() {
    let count = 1;
    for (
      let i = this.width / 2 + this.tickStep;
      i < this.width - this.padding;
      i += this.tickStep
    ) {
      this.ctx.beginPath();
      this.ctx.moveTo(i, this.height / 2);
      this.ctx.lineTo(i, this.height / 2 - (count % 5 == 0 ? 8 : 4));
      this.ctx.stroke();
      if (count % 5 == 0) {
        this.ctx.textAlign = 'center';
        this.ctx.strokeText(`${count}`, i, this.height / 2 + 10);
      }
      count++;
    }
    count = 1;
    for (
      let i = this.width / 2 - this.tickStep;
      i > this.padding;
      i -= this.tickStep
    ) {
      this.ctx.beginPath();
      this.ctx.moveTo(i, this.height / 2);
      this.ctx.lineTo(i, this.height / 2 - (count % 5 == 0 ? 8 : 4));
      this.ctx.stroke();
      if (count % 5 == 0) {
        this.ctx.textAlign = 'center';
        this.ctx.strokeText(`-${count}`, i, this.height / 2 + 10);
      }
      count++;
    }
    count = 1;
    for (
      let i = this.height / 2 + this.tickStep;
      i < this.height - this.padding;
      i += this.tickStep
    ) {
      this.ctx.beginPath();
      this.ctx.moveTo(this.width / 2, i);
      this.ctx.lineTo(this.width / 2 + (count % 5 == 0 ? 8 : 4), i);
      this.ctx.stroke();
      if (count % 5 == 0) {
        this.ctx.textAlign = 'center';
        this.ctx.strokeText(`-${count}`, this.width / 2 - 10, i + 4);
      }
      count++;
    }
    count = 1;
    for (
      let i = this.height / 2 - this.tickStep;
      i > this.padding;
      i -= this.tickStep
    ) {
      this.ctx.beginPath();
      this.ctx.moveTo(this.width / 2, i);
      this.ctx.lineTo(this.width / 2 + (count % 5 == 0 ? 8 : 4), i);
      this.ctx.stroke();
      if (count % 5 == 0) {
        this.ctx.textAlign = 'center';
        this.ctx.strokeText(`${count}`, this.width / 2 - 10, i + 4);
      }
      count++;
    }
  }
}
