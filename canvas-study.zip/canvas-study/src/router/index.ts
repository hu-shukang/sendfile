import { RouteRecordRaw, createRouter, createWebHistory } from 'vue-router';
import Page1 from '../pages/Page1.vue';
import Page2 from '../pages/Page2.vue';
import Page3 from '../pages/Page3.vue';
import Page4 from '../pages/Page4.vue';
import Page5 from '../pages/Page5.vue';
import Page6 from '../pages/Page6.vue';
import Page7 from '../pages/Page7.vue';
import Page8 from '../pages/Page8.vue';
import Page9 from '../pages/Page9.vue';
import Page10 from '../pages/Page10.vue';
import Page11 from '../pages/Page11.vue';
import Page12 from '../pages/Page12.vue';
import Page13 from '../pages/Page13.vue';
import Page14 from '../pages/Page14.vue';

const routes: RouteRecordRaw[] = [
  { path: '/', component: Page1 },
  { path: '/page2', component: Page2 },
  { path: '/page3', component: Page3 },
  { path: '/page4', component: Page4 },
  { path: '/page5', component: Page5 },
  { path: '/page6', component: Page6 },
  { path: '/page7', component: Page7 },
  { path: '/page8', component: Page8 },
  { path: '/page9', component: Page9 },
  { path: '/page10', component: Page10 },
  { path: '/page11', component: Page11 },
  { path: '/page12', component: Page12 },
  { path: '/page13', component: Page13 },
  { path: '/page14', component: Page14 },
];

// 3. Create the router instance and pass the `routes` option
// You can pass in additional options here, but let's
// keep it simple for now.
export const router = createRouter({
  // 4. Provide the history implementation to use. We are using the hash history for simplicity here.
  history: createWebHistory(),
  routes, // short for `routes: routes`
});
