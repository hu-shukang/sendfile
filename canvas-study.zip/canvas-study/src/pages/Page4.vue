<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
const canvas = ref<HTMLCanvasElement>();

const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
const radio = ref(50);
const speed = ref(10); // 200px/s
const range = computed(() => [radio.value / 2, width.value - radio.value / 2]);

class Circle {
  private lastDrawTime: number;
  constructor(
    private ctx: CanvasRenderingContext2D,
    private x: number,
    private y: number,
  ) {
    this.lastDrawTime = -1;
  }

  public move() {
    const duration = Math.min((Date.now() - this.lastDrawTime) / 1000, 0.1);
    const distiance = duration * speed.value;
    this.x = this.x + distiance;
    if (this.x < range.value[0]) {
      this.x = range.value[0];
      speed.value = 0 - speed.value;
    } else if (this.x > range.value[1]) {
      this.x = range.value[1];
      speed.value = 0 - speed.value;
    }
  }

  public draw() {
    this.move();
    this.ctx.clearRect(0, 0, width.value, height.value);
    this.ctx.beginPath();
    this.ctx.arc(this.x, this.y, radio.value, 0, Math.PI * 2);
    this.ctx.fillStyle = '#ffffff';
    this.ctx.fill();
    requestAnimationFrame(() => this.draw());
  }

  public start() {
    requestAnimationFrame(() => this.draw());
  }
}

onMounted(() => {
  if (!canvas.value) {
    return;
  }
  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d') as CanvasRenderingContext2D;
  const circle = new Circle(ctx, 100, 100);
  circle.start();
});
</script>

<style scoped lang="css">
.wrapper {
  background-color: #000000;
}
</style>
