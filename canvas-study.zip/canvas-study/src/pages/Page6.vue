<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { Coordinate } from '../models/coordinate.model';

const canvas = ref<HTMLCanvasElement>();

const width = ref<number>(1000);
const height = ref<number>(500);

onMounted(() => {
  if (!canvas.value) {
    return;
  }
  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d') as CanvasRenderingContext2D;
  const coordinate = new Coordinate({
    ctx: ctx,
    width: width.value,
    height: height.value,
  });
  requestAnimationFrame(() => {
    coordinate.draw();
    // Draw sine function
    ctx.beginPath();
    ctx.strokeStyle = 'red';
    for (let i = 50; i <= width.value - 50; i++) {
      const x = i;
      const y = -Math.sin((x - width.value / 2) / 10) * 10 + height.value / 2;
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();
  });
});
</script>

<style scoped lang="css">
.wrapper {
  display: block;
  width: 1000px;
  border: 1px solid #cccccc;
  margin: 50px auto;
}
</style>
