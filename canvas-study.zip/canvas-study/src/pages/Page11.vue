<template>
  <div>
    <input type="range" v-model="val" min="0" max="1" step="0.01" />
    <div>{{ val }}</div>
    <div class="ball" :style="{ '--delay': `-${val}s` }"></div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const val = ref<number>(0);
</script>

<style scoped lang="css">
.ball {
  --size: 50px;
  --delay: 0s;
  background: red;
  height: var(--size);
  width: var(--size);
  border-radius: 50%;
  animation: move 1s ease-in-out forwards;
  animation-play-state: paused;
  animation-delay: var(--delay);
}

@keyframes move {
  to {
    transform: translateX(200px);
  }
}
</style>
