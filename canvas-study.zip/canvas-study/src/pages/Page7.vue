<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const canvas = ref<HTMLCanvasElement>();

const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
const text = ref<string>('');

const getRandom = (min: number, max: number) => {
  return Math.floor(Math.random() * (max + 1 - min)) + min;
};

class Particle {
  private size: number;
  private x: number;
  private y: number;
  constructor(private ctx: CanvasRenderingContext2D) {
    this.size = getRandom(2, 7);
    const r = Math.min(width.value, height.value) / 2;
    const rad = (getRandom(0, 360) * Math.PI) / 180;
    const cx = width.value / 2;
    const cy = height.value / 2;
    this.x = cx + r * Math.cos(rad);
    this.y = cy + r * Math.sin(rad);
  }

  public draw() {
    this.ctx.beginPath();
    this.ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
    this.ctx.fillStyle = '#5445544d';
    this.ctx.fill();
  }

  public moveTo(tx: number, ty: number) {
    const duration = 500;
    const sx = this.x;
    const sy = this.y;
    const xSpeed = (tx - sx) / duration;
    const ySpeed = (ty - sy) / duration;
    const startTime = Date.now();
    const _move = () => {
      const t = Date.now() - startTime;
      this.x = sx + t * xSpeed;
      this.y = sy + t * ySpeed;
      if (t >= duration) {
        this.x = tx;
        this.y = ty;
        return;
      }
      requestAnimationFrame(() => _move());
    };
    _move();
  }
}

const getText = () => {
  return new Date().toTimeString().substring(0, 8);
};

onMounted(() => {
  if (!canvas.value) {
    return;
  }
  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d', {
    willReadFrequently: true,
  }) as CanvasRenderingContext2D;
  const particleList: Particle[] = [];

  const clear = () => {
    ctx.clearRect(0, 0, width.value, height.value);
  };

  const getPoints = () => {
    const points = [];
    const { data } = ctx.getImageData(0, 0, width.value, height.value);
    const gap = 3;
    for (let i = 0; i < width.value; i += gap) {
      for (let j = 0; j < height.value; j += gap) {
        const index = (i + j * width.value) * 4;
        const r = data[index];
        const g = data[index + 1];
        const b = data[index + 2];
        const a = data[index + 3];
        if (r === 0 && g === 0 && b === 0 && a === 255) {
          points.push([i, j]);
        }
      }
    }
    return points;
  };

  const update = () => {
    const curText = getText();
    if (text.value === curText) {
      return;
    }
    clear();
    text.value = curText;
    ctx.fillStyle = '#000';
    ctx.textBaseline = 'middle';
    ctx.font = `140px 'DS-Digital',sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(text.value, width.value / 2, height.value / 2);
    const points = getPoints();
    clear();
    for (let i = 0; i < points.length; i++) {
      const [x, y] = points[i];
      if (particleList.length <= i) {
        const p = new Particle(ctx);
        particleList.push(p);
      }
      const point = particleList[i];
      point.moveTo(x, y);
    }
    if (points.length < particleList.length) {
      particleList.splice(points.length);
    }
  };

  const draw = (ctx: CanvasRenderingContext2D) => {
    clear();
    update();
    for (const p of particleList) {
      p.draw();
    }
    requestAnimationFrame(() => draw(ctx));
  };

  draw(ctx);
});
</script>

<style scoped lang="css">
.wrapper {
  background: radial-gradient(#fff, #8c738c);
}
</style>
