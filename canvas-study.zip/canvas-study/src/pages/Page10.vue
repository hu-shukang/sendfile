<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const canvas = ref<HTMLCanvasElement>();
const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
const fontSize = 100;

const wrapText = (ctx: CanvasRenderingContext2D, text: string) => {
  const lines: string[] = [];
  let words = text.split(' ');
  const maxWidth = ctx.canvas.width;
  while (words.length !== 0) {
    const line: string[] = [];
    let totalWidth = 0;
    let i = 0;
    for (; i < words.length; i++) {
      const { width } = ctx.measureText(words[i]);
      if (totalWidth + width > maxWidth) {
        break;
      }
      line.push(words[i]);
      totalWidth += width;
    }
    words.splice(0, i);
    lines.push(line.join(' '));
  }
  const totalHeight = lines.length * 100;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  for (let i = 0; i < lines.length; i++) {
    const sx = 0;
    const sy = height.value / 2 - totalHeight / 2 + i * fontSize;

    ctx.fillText(lines[i], sx, sy);
  }
  return lines;
};

onMounted(async () => {
  if (!canvas.value) {
    return;
  }

  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d', {
    willReadFrequently: true,
  }) as CanvasRenderingContext2D;

  const text = 'Hello World, Hello World, Hello World!';
  const linearGradient = ctx.createLinearGradient(
    0,
    0,
    width.value,
    height.value,
  );
  linearGradient.addColorStop(0.3, 'red');
  linearGradient.addColorStop(0.5, 'orange');
  linearGradient.addColorStop(0.7, 'yellow');
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = linearGradient;
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 3;
  ctx.font = `${fontSize}px Helvetica`;
  // ctx.fillText(text, textX, textY);
  // ctx.strokeText(text, textX, textY);

  const result = wrapText(ctx, text);
  console.log(result);
});
</script>

<style scoped lang="css">
.wrapper {
  background: #000;
}
</style>
