<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

type Position = {
  x: number;
  y: number;
};

type PositionMap = Position[][];

const canvas = ref<HTMLCanvasElement>();
const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
let circleArrList: Circle[][] = [];

const getRandom = (min: number, max: number) => {
  return Math.floor(Math.random() * (max + 1 - min)) + min;
};

const getTime = () => {
  return new Date().toTimeString().substring(0, 8);
};

const clear = (ctx: CanvasRenderingContext2D) => {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
};

class Circle {
  private radius: number;
  constructor(
    private ctx: CanvasRenderingContext2D,
    private x: number,
    private y: number,
    private duration: number = 300,
  ) {
    this.radius = getRandom(3, 5);
  }

  public draw() {
    this.ctx.beginPath();
    this.ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
    this.ctx.fillStyle = '#5445544d';
    this.ctx.fill();
  }

  public moveTo(p: Position) {
    const speedX = (p.x - this.x) / this.duration;
    const speedY = (p.y - this.y) / this.duration;
    const startTime = Date.now();
    const sx = this.x;
    const sy = this.y;
    const _move = () => {
      const t = Date.now() - startTime;
      if (t >= this.duration) {
        this.x = p.x;
        this.y = p.y;
        return;
      }
      this.x = speedX * t + sx;
      this.y = speedY * t + sy;
      requestAnimationFrame(() => _move());
    };
    _move();
  }
}

class Text {
  private charArr: string[];
  public positionArrList: PositionMap;
  constructor(
    private ctx: CanvasRenderingContext2D,
    private text: string,
    private ch: number,
    private cw: number,
    private gap: number = 3,
  ) {
    this.charArr = this.text.split('');
    this.positionArrList = Array(this.charArr.length).fill([]);
    clear(this.ctx);
    for (let i = 0; i < this.charArr.length; i++) {
      const positions = this.getPositionsByChar(i, this.charArr[i]);
      this.positionArrList[i] = positions;
    }
    clear(this.ctx);
  }

  public update(text: string) {
    const newCharArr = text.split('');
    const newPositionMap: PositionMap = [];
    let result = Array(newCharArr.length).fill(false);
    for (let i = 0; i < newCharArr.length; i++) {
      if (newCharArr[i] === this.charArr[i]) {
        newPositionMap[i] = this.positionArrList[i];
      } else {
        result[i] = true;
        const positions = this.getPositionsByChar(i, newCharArr[i]);
        newPositionMap.push(positions);
      }
    }
    this.positionArrList = newPositionMap;
    this.charArr = newCharArr;
    clear(this.ctx);
    return result;
  }

  private getPositionsByChar(charIndex: number, char: string): Position[] {
    const canvasWidth = this.ctx.canvas.width;
    const canvasHeight = this.ctx.canvas.height;
    const textWidth = this.cw * this.charArr.length;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.font = `140px 'DS-Digital',sans-serif`;
    this.ctx.fillStyle = '#000';
    const sx = canvasWidth / 2 - textWidth / 2 + this.cw * charIndex;
    const sy = canvasHeight / 2 - this.ch / 2;
    const x = sx + this.cw / 2;
    const y = canvasHeight / 2;
    this.ctx.fillText(char, x, y, this.cw);
    const { data } = this.ctx.getImageData(sx, sy, this.cw, this.ch);
    const result: Position[] = [];
    for (let i = 0; i < this.cw; i += this.gap) {
      for (let j = 0; j < this.ch; j += this.gap) {
        const index = (j * this.cw + i) * 4;
        const red = data[index];
        const green = data[index + 1];
        const blue = data[index + 2];
        const alpha = data[index + 3];
        if (red === 0 && green === 0 && blue === 0 && alpha === 255) {
          result.push({ x: i + sx, y: j + sy });
        }
      }
    }
    return result;
  }
}

const updateAll = (ctx: CanvasRenderingContext2D, text: Text) => {
  const newTime = getTime();
  const updateResult = text.update(newTime);
  if (updateResult.every((r) => !r)) {
    return;
  }
  const newPositionArrList = text.positionArrList;
  for (let i = 0; i < updateResult.length; i++) {
    if (!updateResult[i]) {
      continue;
    }
    for (let j = 0; j < newPositionArrList[i].length; j++) {
      if (j < circleArrList[i].length) {
        circleArrList[i][j].moveTo(newPositionArrList[i][j]);
      } else {
        const p = newPositionArrList[i][j];
        circleArrList[i].push(new Circle(ctx, p.x, p.y));
      }
    }
    if (circleArrList[i].length > newPositionArrList[i].length) {
      circleArrList[i].splice(newPositionArrList[i].length);
    }
  }
};

const drawAll = (ctx: CanvasRenderingContext2D, text: Text) => {
  updateAll(ctx, text);
  for (const arr of circleArrList) {
    for (const circle of arr) {
      circle.draw();
    }
  }
  requestAnimationFrame(() => drawAll(ctx, text));
};

onMounted(async () => {
  if (!canvas.value) {
    return;
  }

  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d', {
    willReadFrequently: true,
  }) as CanvasRenderingContext2D;

  const time = getTime();
  const text = new Text(ctx, time, 140, 74);
  circleArrList = text.positionArrList.map((positions) =>
    positions.map((p) => new Circle(ctx, p.x, p.y)),
  );
  drawAll(ctx, text);
});
</script>

<style scoped lang="css">
.wrapper {
  background: radial-gradient(#fff, #8c738c);
}
</style>
