<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
    <!-- <span style="font-family: 'DS-Digital'; font-size: 140px">2</span> -->
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const canvas = ref<HTMLCanvasElement>();

const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
const circleArrList = ref<Array<Array<Circle>>>(Array(8).fill([]));
const getRandom = (min: number, max: number) => {
  return Math.floor(Math.random() * (max + 1 - min)) + min;
};

class Circle {
  private radius: number;
  private duration = 500;
  public target: undefined | { x: number; y: number } = undefined;
  constructor(
    private ctx: CanvasRenderingContext2D,
    public x: number,
    public y: number,
  ) {
    this.radius = getRandom(2, 6);
  }

  public move() {
    if (!this.target) {
      return;
    }
    const startTime = Date.now();
    const speedX = (this.target.x - this.x) / this.duration;
    const speedY = (this.target.y - this.y) / this.duration;
    const _move = () => {
      const t = Date.now() - startTime;
      this.x = this.x + t * speedX;
      this.y = this.y + t * speedY;
      if (t >= this.duration) {
        this.x = this.target!.x;
        this.y = this.target!.y;
        return;
      }
      requestAnimationFrame(() => _move());
    };
    _move();
  }

  public draw() {
    this.ctx.beginPath();
    this.ctx.fillStyle = '#5445544d';
    this.ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
    this.ctx.fill();
  }
}

class Text {
  private textList: string[];
  private fontSize = 140;
  private gap = 3;
  constructor(private ctx: CanvasRenderingContext2D) {
    this.textList = Array(8).fill('');
  }

  private getCircleListForChat(
    x: number,
    y: number,
    index: number,
    chat: string,
  ) {
    if (this.textList[index] === chat) {
      return;
    }
    this.ctx.fillStyle = '#000';
    this.ctx.textBaseline = 'middle';
    this.ctx.font = `${this.fontSize}px 'DS-Digital'`;
    this.ctx.textAlign = 'center';
    this.ctx.fillText(chat, x, y);
    const left = x - this.width / 2;
    const top = y - this.height / 2;
    const { data } = this.ctx.getImageData(left, top, this.width, this.height);
    const circleList = [];
    let count = 0;
    for (let i = 0; i < this.width; i += this.gap) {
      for (let j = 0; j < this.height; j += this.gap) {
        const idx = (j * this.width + i) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const a = data[idx + 3];
        if (r === 0 && g === 0 && b === 0 && a === 255) {
          if (count < circleArrList.value[index].length) {
            const circle = new Circle(
              this.ctx,
              circleArrList.value[index][count].x,
              circleArrList.value[index][count].y,
            );
            circle.target = { x: left + i, y: top + j };
            circleList.push(circle);
          } else {
            circleList.push(new Circle(this.ctx, left + i, top + j));
          }
          count++;
        }
      }
    }

    circleArrList.value[index] = circleList;
  }

  get height() {
    return this.fontSize;
  }

  get width() {
    return this.fontSize / 2;
  }

  public draw() {
    requestAnimationFrame(() => this.draw());
    this.ctx.clearRect(0, 0, width.value, height.value);
    const totalWidth = this.textList.length * this.width;
    const newTextList = new Date().toTimeString().substring(0, 8).split('');
    for (let i = 0; i < this.textList.length; i++) {
      const x =
        width.value / 2 - totalWidth / 2 + this.width * i + this.width / 2;
      const y = height.value / 2;
      this.getCircleListForChat(x, y, i, newTextList[i]);
    }
    this.ctx.clearRect(0, 0, width.value, height.value);
    this.textList = newTextList;
    for (const list of circleArrList.value) {
      for (const item of list) {
        // item.move();
        item.draw();
      }
    }
  }
}

onMounted(() => {
  if (!canvas.value) {
    return;
  }
  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d', {
    willReadFrequently: true,
  }) as CanvasRenderingContext2D;
  const text = new Text(ctx);
  text.draw();
});
</script>

<style scoped lang="css">
.wrapper {
  background: radial-gradient(#fff, #8c738c);
}
</style>
