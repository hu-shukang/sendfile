<template>
  <canvas ref="canvas" width="800" height="500"></canvas>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
const canvas = ref<HTMLCanvasElement>();

onMounted(() => {
  const ctx = canvas.value!.getContext('2d') as CanvasRenderingContext2D;
  ctx.strokeStyle = '#ff0000';
  ctx.strokeRect(100, 100, 200, 50);

  ctx.beginPath();
  ctx.strokeStyle = '#00ff00';
  ctx.moveTo(200, 200);
  ctx.lineTo(400, 200);
  ctx.lineTo(400, 50);
  ctx.closePath();
  ctx.lineWidth = 5;
  ctx.stroke();
});
</script>
