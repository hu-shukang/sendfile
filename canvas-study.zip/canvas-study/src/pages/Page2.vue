<template>
  <canvas ref="canvas" width="800" height="500"></canvas>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
const canvas = ref<HTMLCanvasElement>();

onMounted(() => {
  const ctx = canvas.value!.getContext('2d') as CanvasRenderingContext2D;
  ctx.beginPath();
  ctx.strokeStyle = '#ff0000';
  ctx.lineWidth = 4;
  ctx.arc(100, 100, 80, 0, 1, false);
  ctx.stroke();
});
</script>
