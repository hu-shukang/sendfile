<template>
  <div class="container" @mouseleave="mouseUpHandler">
    <img
      :src="imgSrc"
      alt=""
      :style="{ left: x, top: y }"
      @mousedown="mouseDownHandler"
      @mousemove="mouseMoveHandler"
      @mouseup="mouseUpHandler"
      draggable="false"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const x = ref<string>('40%');
const y = ref<string>('40%');
const random = Math.ceil(Math.random() * 4);
const imgSrc = ref<string>(`0${random}.png`);
let offsetX: number = 0;
let offsetY: number = 0;
let isDragging = false;

const channel = new BroadcastChannel('card');

channel.onmessage = (e: MessageEvent) => {
  console.log(e.data);
  const { screenX, screenY } = e.data;
  const { clientX, clientY } = screenToClient(screenX, screenY);
  console.log(clientX, clientY);
  x.value = `${clientX}px`;
  y.value = `${clientY}px`;
};

const barHeight = () => {
  return window.outerHeight - window.innerHeight;
};

const clientToScreen = (clientX: number, clientY: number) => {
  const screenX = clientX + window.screenX;
  const screenY = clientY + window.screenY + barHeight();
  return { screenX, screenY };
};

const screenToClient = (screenX: number, screenY: number) => {
  const clientX = screenX - window.screenX;
  const clientY = screenY - window.screenY - barHeight();
  return { clientX, clientY };
};

const mouseDownHandler = (e: any) => {
  offsetX = e.clientX - e.target!.getBoundingClientRect().left;
  offsetY = e.clientY - e.target!.getBoundingClientRect().top;
  isDragging = true;
};

const mouseMoveHandler = (e: MouseEvent) => {
  if (!isDragging) {
    return;
  }
  const clientX = e.clientX - offsetX;
  const clientY = e.clientY - offsetY;
  x.value = `${clientX}px`;
  y.value = `${clientY}px`;
  const screenPos = clientToScreen(clientX, clientY);
  channel.postMessage(screenPos);
};

const mouseUpHandler = () => {
  isDragging = false;
};
</script>

<style scoped lang="scss">
.container {
  width: 100vw;
  height: 100vh;
  position: relative;
  overflow: hidden;
  img {
    position: absolute;
  }
}
</style>
