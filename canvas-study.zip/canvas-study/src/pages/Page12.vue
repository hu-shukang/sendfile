<template>
  <div @mousemove="mouseMoveHandler" class="grid">
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
    <div :ref="puthRef" class="container">
      <div class="inner">inner content</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
const containerRefList = ref<HTMLDivElement[]>([]);

const puthRef = (el: any) => {
  containerRefList.value.push(el);
};

const mouseMoveHandler = (e: MouseEvent) => {
  for (const containerRef of containerRefList.value) {
    const rect = containerRef.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    containerRef.style.setProperty('--x', `${x}px`);
    containerRef.style.setProperty('--y', `${y}px`);
  }
};
</script>

<style scoped lang="css">
.grid {
  background-color: #000000;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  row-gap: 10px;
  column-gap: 10px;
  padding: 10px;
  .container {
    width: 100%;
    aspect-ratio: 1;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 0.1);
    position: relative;
    overflow: hidden;
    &::before {
      z-index: 2;
      content: '';
      position: absolute;
      width: 100%;
      height: 100%;
      left: var(--x, -1000px);
      top: var(--y, -1000px);
      background: radial-gradient(
        closest-side circle,
        rgba(255, 255, 255, 0.3) 0%,
        transparent
      );
      border-radius: inherit;
      transform: translate(-50%, -50%);
    }
    .inner {
      position: absolute;
      background-color: #171717;
      inset: 2px;
      color: #ffffff;
      padding: 20px;
      border-radius: inherit;
      z-index: 3;
    }
  }
}
</style>
