<template>
  <div class="wrapper">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
const canvas = ref<HTMLCanvasElement>();

const width = ref<number>(800);
const height = ref<number>(500);

class Rectangle {
  public endX: number;
  public endY: number;

  constructor(
    private ctx: CanvasRenderingContext2D,
    private color: string,
    private startX: number,
    private startY: number,
  ) {
    this.endX = this.startX;
    this.endY = this.startY;
  }

  public draw() {
    this.ctx.clearRect(0, 0, width.value, height.value);
    this.ctx.beginPath();
    this.ctx.rect(
      this.startX,
      this.startY,
      this.endX - this.startX,
      this.endY - this.startY,
    );
    this.ctx.fillStyle = this.color;
    this.ctx.fill();
  }

  get minX() {
    return Math.min(this.startX, this.endX);
  }

  get maxX() {
    return Math.max(this.startX, this.endX);
  }

  get minY() {
    return Math.min(this.startY, this.endY);
  }

  get maxY() {
    return Math.max(this.startY, this.endY);
  }
}

const shapes = [] as Rectangle[];

onMounted(() => {
  if (!canvas.value) {
    return;
  }
  canvas.value.width = width.value;
  canvas.value.height = height.value;
  const ctx = canvas.value!.getContext('2d') as CanvasRenderingContext2D;
  const rectangle = new Rectangle(ctx, 'red', 0, 0);
  rectangle.endX = 300;
  rectangle.endY = 300;

  canvas.value.onmousedown = (e) => {
    const rect = canvas.value!.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;
    const shape = new Rectangle(ctx, 'red', clickX, clickY);
    shapes.push(shape);
    window.onmousemove = (wmme) => {
      shape.endX = wmme.clientX - rect.left;
      shape.endY = wmme.clientY - rect.top;
      requestAnimationFrame(() => shape.draw());
    };

    window.onmouseup = () => {
      window.onmousemove = null;
      window.onmouseup = null;
    };
  };
});
</script>

<style scoped lang="css">
.wrapper {
  display: block;
  width: 800px;
  background-color: #cccccc;
  margin: 50px auto;
}
</style>
