<template>
  <div ref="containerRef" class="container">
    <div ref="ballRef" class="ball"></div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const containerRef = ref<HTMLDivElement>(null!);
const ballRef = ref<HTMLDivElement>(null!);

const pointList: Array<HTMLDivElement> = [];

const trackBall = () => {
  const ballRect = ballRef.value.getBoundingClientRect();

  // 创建轨迹点
  const trackPoint = document.createElement('div');
  trackPoint.classList.add('track-point');
  trackPoint.style.left = `${ballRect.left + ballRect.width / 2}px`;
  trackPoint.style.top = `${ballRect.top + ballRect.height / 2}px`;
  pointList.push(trackPoint);
  containerRef.value.appendChild(trackPoint);
  if (pointList.length > 300) {
    for (let i = 0; i < 10; i++) {
      containerRef.value.removeChild(pointList[i]);
    }
    pointList.splice(0, 10);
  }

  requestAnimationFrame(trackBall);
};

onMounted(() => {
  trackBall();
});
</script>

<style scoped lang="scss">
@property --x {
  syntax: '<length>';
  initial-value: 0px;
  inherits: false;
}
@property --y {
  syntax: '<length>';
  initial-value: 0px;
  inherits: false;
}
.container {
  --size: 20px;
  height: 100vh;
  width: 100vw;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  :global(.track-point) {
    position: absolute;
    width: 5px; /* 轨迹点的大小 */
    height: 5px;
    border-radius: 50%;
    background-color: blue; /* 轨迹点的颜色 */
    transform: translate(-50%, -50%);
  }
  .ball {
    transform: translate(var(--x), var(--y));
    height: var(--size);
    width: var(--size);
    border-radius: 50%;
    background-color: red;
    z-index: 2;
    animation:
      x 2s,
      y 1s;
    animation-timing-function: cubic-bezier(0.31, -500, 0.67, 500);
    animation-fill-mode: forwards;
    animation-iteration-count: infinite;
  }

  @keyframes x {
    to {
      --x: 1px;
    }
  }

  @keyframes y {
    to {
      --y: 0.4px;
    }
  }
}
</style>
