<template>
  <transition-group name="row-move" tag="table">
    <tr
      v-for="(row, index) in rows"
      :key="row.id"
      draggable="true"
      @dragstart="dragStart(index)"
      @dragover.prevent="dragOver(index)"
      @drop="drop"
    >
      <td>
        <i class="icon icon-drag-handle"></i>
      </td>
      <td>{{ row.data }}</td>
    </tr>
  </transition-group>
</template>

<script setup lang="ts">
import { ref } from 'vue';
const rows = ref([
  { id: 1, data: 'Row 1' },
  { id: 2, data: 'Row 2' },
  { id: 3, data: 'Row 3' },
  { id: 4, data: 'Row 4' },
]);
const dragIndex = ref<number>();
const dragStart = (index: number) => {
  dragIndex.value = index;
};
const dragOver = (index: number) => {
  if (dragIndex.value && index !== dragIndex.value) {
    const [movedItem] = rows.value.splice(dragIndex.value, 1);
    rows.value.splice(index, 0, movedItem);
    dragIndex.value = index;
  }
};

const drop = (event: Event) => {
  event.preventDefault();
};
</script>

<style scoped lang="css">
.row-move-move {
  transition: transform 0.5s ease-in-out;
}
</style>
