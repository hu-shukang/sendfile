<template>
  <router-view></router-view>
</template>

<style lang="scss">
body {
  padding: 0;
  margin: 0;
}
</style>
